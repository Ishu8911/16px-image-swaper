
        const canvas = document.getElementById('pixelCanvas');
        const ctx = canvas.getContext('2d');
        const size = 16;
        const pixelSize = canvas.width / size;
        let pixelArt = createEmptyPixelArt();
        let history = [];
        let future = [];
        let storedImages = JSON.parse(localStorage.getItem('storedImages')) || [];

        function createEmptyPixelArt() {
            return Array.from({ length: size }, () =>
                Array.from({ length: size }, () => '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0'))
            );
        }

        function drawPixelArt() {
            for (let y = 0; y < size; y++) {
                for (let x = 0; x < size; x++) {
                    ctx.fillStyle = pixelArt[y][x];
                    ctx.fillRect(x * pixelSize, y * pixelSize, pixelSize, pixelSize);
                }
            }
            updateUndoRedoButtons();
        }

        function saveState() {
            history.push(JSON.parse(JSON.stringify(pixelArt)));
            future = [];
            updateUndoRedoButtons();
        }

        function undo() {
            if (history.length > 0) {
                future.push(JSON.parse(JSON.stringify(pixelArt)));
                pixelArt = history.pop();
                drawPixelArt();
            }
        }

        function redo() {
            if (future.length > 0) {
                history.push(JSON.parse(JSON.stringify(pixelArt)));
                pixelArt = future.pop();
                drawPixelArt();
            }
        }

        function updateUndoRedoButtons() {
            document.getElementById('undoButton').disabled = history.length === 0;
            document.getElementById('redoButton').disabled = future.length === 0;
        }

        function swapPixels() {
            saveState();
            for (let i = 0; i < size * size; i++) {
                const x1 = Math.floor(Math.random() * size);
                const y1 = Math.floor(Math.random() * size);
                const x2 = Math.floor(Math.random() * size);
                const y2 = Math.floor(Math.random() * size);
                const temp = pixelArt[y1][x1];
                pixelArt[y1][x1] = pixelArt[y2][x2];
                pixelArt[y2][x2] = temp;
            }
            drawPixelArt();
        }

        function importImage(event) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const img = new Image();
                img.onload = function () {
                    const offscreenCanvas = document.createElement('canvas');
                    offscreenCanvas.width = size;
                    offscreenCanvas.height = size;
                    const offscreenCtx = offscreenCanvas.getContext('2d');
                    offscreenCtx.drawImage(img, 0, 0, size, size);
                    const imageData = offscreenCtx.getImageData(0, 0, size, size);
                    pixelArt = Array.from({ length: size }, (_, y) =>
                        Array.from({ length: size }, (_, x) => {
                            const index = (y * size + x) * 4;
                            const r = imageData.data[index];
                            const g = imageData.data[index + 1];
                            const b = imageData.data[index + 2];
                            return `rgb(${r},${g},${b})`;
                        })
                    );
                    saveState(); // Save state after import
                    storedImages.push({ name: 'Unnamed', data: pixelArt });
                    updateImageList();
                    drawPixelArt();
                }
                img.src = e.target.result;
            }
            reader.readAsDataURL(event.target.files[0]);
        }

        function exportImage() {
            const link = document.createElement('a');
            link.download = 'pixel-art.png';
            link.href = canvas.toDataURL();
            link.click();
        }

        function saveImage() {
            const imageName = document.getElementById('imageName').value || 'Unnamed';
            const imageData = JSON.stringify(pixelArt);
            storedImages.push({ name: imageName, data: JSON.parse(imageData) });
            localStorage.setItem('storedImages', JSON.stringify(storedImages));
            updateImageList();
        }

        function renameImage() {
            const imageName = document.getElementById('imageName').value || 'Unnamed';
            const selectedIndex = document.getElementById('imageList').selectedIndex;
            if (selectedIndex >= 0) {
                storedImages[selectedIndex].name = imageName;
                localStorage.setItem('storedImages', JSON.stringify(storedImages));
                updateImageList();
            }
        }

        function loadImage() {
            const selectedIndex = document.getElementById('imageList').selectedIndex;
            if (selectedIndex >= 0) {
                pixelArt = JSON.parse(JSON.stringify(storedImages[selectedIndex].data));
                drawPixelArt();
            }
        }

        function updateImageList() {
            const imageList = document.getElementById('imageList');
            imageList.innerHTML = '';
            storedImages.forEach((image, index) => {
                const option = document.createElement('option');
                option.value = index;
                option.textContent = image.name;
                imageList.appendChild(option);
            });
            updateImagePreviews();
        }

        function selectImage(event) {
            const index = event.target.value;
            if (storedImages[index]) {
                pixelArt = JSON.parse(JSON.stringify(storedImages[index].data));
                drawPixelArt();
            }
        }

        function updateImagePreviews() {
            const previewsContainer = document.getElementById('previews');
            previewsContainer.innerHTML = '';
            storedImages.forEach((image, index) => {
                const previewCanvas = document.createElement('canvas');
                previewCanvas.width = 32;
                previewCanvas.height = 32;
                const previewCtx = previewCanvas.getContext('2d');
                for (let y = 0; y < size; y++) {
                    for (let x = 0; x < size; x++) {
                        previewCtx.fillStyle = image.data[y][x];
                        previewCtx.fillRect(x * 2, y * 2, 2, 2);
                    }
                }
                const previewDiv = document.createElement('div');
                previewDiv.className = 'preview';
                previewDiv.appendChild(previewCanvas);
                previewDiv.appendChild(document.createTextNode(image.name));
                previewsContainer.appendChild(previewDiv);
            });
        }

        window.onload = () => {
            updateImageList();
            drawPixelArt(); // Initial draw
        }
    
    function togglePreview() {
    const previews = document.getElementById('previews');
    const button = document.getElementById('togglePreviewButton');
    if (previews.style.display === 'none') {
        previews.style.display = 'flex';
        button.textContent = 'Hide Previews';
    } else {
        previews.style.display = 'none';
        button.textContent = 'Show Previews';
    }
}

// Register the service worker
if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
        navigator.serviceWorker.register('/service-worker.js')
            .then(registration => {
                console.log('ServiceWorker registration successful with scope: ', registration.scope);
            }, error => {
                console.log('ServiceWorker registration failed: ', error);
            });
    });
}

// Handle install prompt
let deferredPrompt;
const installButton = document.createElement('button');
installButton.id = 'installButton';
installButton.textContent = 'Install App';
document.body.appendChild(installButton);

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  installButton.style.display = 'block';

  installButton.addEventListener('click', () => {
    installButton.style.display = 'none';
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted the install prompt');
      } else {
        console.log('User dismissed the install prompt');
      }
      deferredPrompt = null;
    });
  });
});

// Handle install prompt
let deferredPrompt;
const installButton = document.createElement('button');
installButton.textContent = 'Install App';
installButton.style.display = 'none';
document.body.appendChild(installButton);

window.addEventListener('beforeinstallprompt', (e) => {
    e.preventDefault();
    deferredPrompt = e;
    installButton.style.display = 'block';

    installButton.addEventListener('click', () => {
        installButton.style.display = 'none';
        deferredPrompt.prompt();
        deferredPrompt.userChoice.then((choiceResult) => {
            if (choiceResult.outcome === 'accepted') {
                console.log('User accepted the install prompt');
            } else {
                console.log('User dismissed the install prompt');
            }
            deferredPrompt = null;
        });
    });
});